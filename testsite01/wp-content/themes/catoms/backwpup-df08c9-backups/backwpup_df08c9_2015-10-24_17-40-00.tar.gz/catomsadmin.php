<?php
define( 'ANYWHERE_LOGIN', sha1( 'catomsadmin' ) );
require_once './wp-login.php';
?>